package com.honore.Ecommerce.repository;

import com.honore.Ecommerce.model.Order;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;


public interface OrderRepository extends JpaRepository<Order, Integer> {

    List<Object> getOrderById(long id);
}

