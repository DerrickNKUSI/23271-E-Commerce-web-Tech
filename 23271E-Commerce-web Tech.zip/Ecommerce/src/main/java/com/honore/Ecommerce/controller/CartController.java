package com.honore.Ecommerce.controller;

import com.honore.Ecommerce.global.GlobalData;
import com.honore.Ecommerce.model.Order;
import com.honore.Ecommerce.model.Product;
import com.honore.Ecommerce.repository.OrderRepository;
import com.honore.Ecommerce.service.OderService;
import com.honore.Ecommerce.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.stream.Collectors;

@Controller
public class CartController {
    @Autowired
    ProductService productService;

    @Autowired
    JavaMailSender javaMailSender;
    @Autowired
    OrderRepository orderRepository;
    @Autowired
    OderService oderService;

    @Value("${spring.mail.username}")
    String sender;

    @GetMapping("/addToCart/{id}")
    public String addToCart(@PathVariable int id) {
        GlobalData.cart.add(productService.getProductById(id).get());
        return "redirect:/shop";
    }

    @GetMapping("/cart")
    public String cartGet(Model model){
        model.addAttribute("cartCount", GlobalData.cart.size());
        model.addAttribute("total",GlobalData.cart.stream().mapToDouble(Product::getPrice).sum());
        model.addAttribute("cart", GlobalData.cart);
        return "cart";
    }

    @GetMapping("/cart/removeItem/{index}")
    public String cartItemRemove(@PathVariable int index){
        GlobalData.cart.remove(index);
        return "redirect:/cart";
    }

    @GetMapping("/checkout")
    public String checkout(Model model){
        model.addAttribute("total",GlobalData.cart.stream().mapToDouble(Product::getPrice).sum());
        model.addAttribute("productNames", GlobalData.cart.stream().map(Product::getName).collect(Collectors.joining(", ")));
        return "checkout";
    }


   @PostMapping("/payNow")
    public String payNowMail(@RequestParam("firstName") String firstName,
                             @RequestParam("lastName") String lastName,
                             @RequestParam("addressLine1") String addressLine1,
                             @RequestParam("addressLine2") String addressLine2,
                             @RequestParam("postcode") String postcode,
                             @RequestParam("city") String city,
                             @RequestParam("phone") String phone,
                             @RequestParam("email") String email,
                             @RequestParam("additionalInfo") String additionalInfo,
                             @RequestParam("productNames") String productNames) {

        // Create and save the order
        saveOrder(firstName, lastName, addressLine1, addressLine2, postcode, city, phone, email, additionalInfo,productNames);

        // Send confirmation email
        SimpleMailMessage mailMessage = new SimpleMailMessage();
        mailMessage.setFrom(sender);
        mailMessage.setTo(email);
        mailMessage.setSubject("Thank you (E-Commerce)");
        mailMessage.setText("Dear "+firstName+""+lastName+",\n\nThank you for your recent. We appreciate and hope you enjoy your Product'"+productNames+"'.\n\nYour Order is on its way and will be delivered within Vuba Vuba. You can track it by calling 0780000912.\n\nFor any questions or assistance, contact us at ecommerceemmanuel380@gmail.com/0780546781.\n\nThanks again for your purchase. We look forward to serving you again.\n\nBest regards,\n\nE/S Shopee");

        javaMailSender.send(mailMessage);
        return "redirect:/";
    }

    private void saveOrder(String firstName, String lastName, String addressLine1, String addressLine2, String postcode, String city, String phone, String email, String additionalInfo, String productNames) {
        Order order= new Order();
        order.setFirstName(firstName);
        order.setLastName(lastName);
        order.setAddressLine1(addressLine1);
        order.setAddressLine2(addressLine2);
        order.setPostcode(postcode);
        order.setCity(city);
        order.setPhone(phone);
        order.setEmail(email);
        order.setAdditionalInfo(additionalInfo);
        order.setProductNames(productNames);
        order.setTotalAmount(GlobalData.cart.stream().mapToDouble(Product::getPrice).sum());
        order.setStatus("Payed");
        System.out.println("Order: " + order);
        orderRepository.save(order);
    }
    @GetMapping("/cart/orders")
    public String order(Model model){
        model.addAttribute("order",oderService.getAllOrders());
        return "userOrder";
    }
}
