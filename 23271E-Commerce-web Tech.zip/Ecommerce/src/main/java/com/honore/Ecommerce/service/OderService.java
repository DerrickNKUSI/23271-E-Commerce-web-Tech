package com.honore.Ecommerce.service;

import com.honore.Ecommerce.model.Order;
import com.honore.Ecommerce.model.Product;
import com.honore.Ecommerce.repository.OrderRepository;
import com.honore.Ecommerce.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class OderService {
    @Autowired
    OrderRepository orderRepository;
    public List<Order> getAllOrders(){
        return orderRepository.findAll();}


    public void approveOrder(int id) {
        Optional<Order> orderOptional = orderRepository.findById(id);
        if (orderOptional.isPresent()) {
            Order order = orderOptional.get();
            order.setStatus("approved");
            orderRepository.save(order);
        }
    }
}
