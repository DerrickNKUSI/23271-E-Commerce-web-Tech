//package com.honore.Ecommerce.repository;
//
//import com.honore.Ecommerce.model.Role;
//import org.springframework.data.jpa.repository.JpaRepository;
//
//public interface RoleRepository extends JpaRepository<Role, Integer> {
//}
