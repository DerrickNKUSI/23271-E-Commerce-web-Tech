package com.honore.Ecommerce.service;

import com.fasterxml.jackson.databind.Module;
import com.honore.Ecommerce.model.User;
import com.honore.Ecommerce.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.ModelAttribute;

import java.util.Optional;

@Service
public class UserService {
    @Autowired
    UserRepository userRepository;

    public boolean registerUser(@ModelAttribute("user") User user) {
        userRepository.save(user);
        return userRepository.existsById(user.getId());
    }

    public String EmailExist(User user) {
        Optional<User> emailExist = userRepository.getUserByEmail(user.getEmail());
        if (emailExist.isPresent()) {
            return "yes";
        } else {
            return "no";
        }
    }
}
