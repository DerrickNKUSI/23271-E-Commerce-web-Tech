package com.honore.Ecommerce.controller;

//import com.honore.Ecommerce.repository.RoleRepository;
import com.honore.Ecommerce.repository.UserRepository;
import com.honore.Ecommerce.global.GlobalData;
//import com.honore.Ecommerce.model.Role;
import com.honore.Ecommerce.model.User;
import com.honore.Ecommerce.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import javax.servlet.http.HttpSession;
@Controller
public class LoginController {
    @Autowired
    private BCryptPasswordEncoder bCryptPasswordEncoder;
    @Autowired
    UserRepository userRepository;
    @Autowired
    UserService userService;
   // @Autowired
    //RoleRepository roleRepository;

    @GetMapping("/login")
    public String login(){
        GlobalData.cart.clear();
        return "login";
    }

    @GetMapping("/logout")
     public String logout(HttpSession session){

            session.invalidate();
            return "login";


    }

    @GetMapping("/register")
    public String registerGet(){


        return "register";
    }

    @PostMapping("/register")
    public String registerPost(@ModelAttribute("user") User user, RedirectAttributes red, HttpServletRequest request)throws ServletException{
        String password =user.getPassword();
        user.setPassword(bCryptPasswordEncoder.encode(password));
  //      List<Role> roles = new ArrayList<>();
//        roles.add(roleRepository.findById(2).get());
 //       roleRepository.findById(2).ifPresent(role -> roles.add(role));
        // user.setRoles(roles);
        //userRepository.save(user);
        // request.login(user.getEmail(),password);
        user.setUsertype("USER");
        String checkEmail = userService.EmailExist(user);
        if (checkEmail.equals("no"))
        {if (userService.registerUser(user)) {
            red.addFlashAttribute("message", "User signed up Successfully");
                return "redirect:/";
            } else {
            red.addFlashAttribute("message", "User sign up Failed");
                return "redirect:/register";
            }
        } else {
            red.addFlashAttribute("message", "User is Already Exist");
            return "redirect:/register";
        }
    }

}













